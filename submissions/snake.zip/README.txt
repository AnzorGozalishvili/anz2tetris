# SNAKE Game


## Description

Control the snake to eat as much fruit as you can. The snake grows with each fruit eaten.

The game is over if the snake moves into a wall or collides with itself.

You can win the game by growing the snake to occupy all of the available space.


## Controls

arrow up / W: turn north
arrow down / S: turn south
arrow left / A: turn west
arrow right / D: turn east


## Running the game

Please use the NAND2Tetris Web IDE at <https://nand2tetris.github.io/web-ide/vm> to run the game.

Make sure to set the emulation speed slider all the way to "Fast".