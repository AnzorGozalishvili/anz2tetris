# Jack Analyzer Logic

1. Call `JackAnalyzer.py` and pass either a `.jack` file or directory containing `.jack` files
2. Main method supports two modes:
   - Tokenizer only mode (with `--tokens` flag)
   - Full parsing mode (default)

3. **Tokenizer Mode (`--tokens` flag)**:
   1. Creates `*T.xml` file for token output
   2. JackTokenizer processes input file:
      - Removes comments and whitespace
      - Identifies tokens (keywords, symbols, identifiers, integers, strings)
      - Writes tokens in XML format:
         ```xml
         <tokens>
           <keyword> class </keyword>
           <identifier> Main </identifier>
           <symbol> { </symbol>
           ...
         </tokens>
         ```

4. **Full Parsing Mode**:
   1. Creates `.xml` file for parsed output
   2. Uses CompilationEngine for recursive descent parsing:
      - Starts with `compileClass()`
      - Handles program structure:
         ```xml
         <class>
           <keyword> class </keyword>
           <identifier> Main </identifier>
           <symbol> { </symbol>
           ...
         </class>
         ```
      - Processes declarations, statements, expressions
      - Maintains proper XML structure and indentation

5. **Development Stages**:
   1. Stage 1: Tokenizer implementation and testing
   2. Stage 2: Basic parsing without expressions
   3. Stage 3: Expression handling
   4. Stage 4: Array access support

6. **Testing**:
   - Use `make test-tokenizer` for tokenizer tests
   - Use `make test-parser` for parser tests
   - Use `make test` for all tests
   - Compare output with provided test files using TextComparer

7. **Special Handling**:
   - XML special characters (<, >, &) are escaped
   - Comments (// and /* */) are removed
   - Proper indentation in output XML
   - Expression list counting for future VM code generation